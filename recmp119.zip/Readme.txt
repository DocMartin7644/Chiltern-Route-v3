ReCompiler V1.1.9
----------

This is a pair of utilities that allow for manipulation of MSTS1 World (.W), 
Shape (.s) and Terrain (.T) files. One of them (DeComp.exe) will allow you 
to take a binary compressed version of a file and expand it into a Unicode 
text version. The other utility (Comp.exe) will allow you to tokenize and 
compress the unicode versions of the file.

Installation
------------

The distribution zip file contains two internal zip files, one for each 
utility. Extract each zip file to seperate locations. Then, one at a time, 
open each zip file and launch the Setup.exe program to perform the install. 
DO NOT replace existing dll or ocx file if asked to do so. READ THE MESSAGE 
CAREFULLY BEFORE RESPONDING!

Usage
-----

The usage of these two programs is relatively straight forward, and esentially 
the same. 
After starting, select the radio button that represents the type of file you want to process.
Press the Source button to navigate to the input file to be processed.
Press the Target button to navigate to where the output file will be written.
Press the proceed button to start the action.
Running status is displayed in the Status text box.
DeCompiles run reasonably fast.
Compiles take a little bit longer for some of the larger .W and .S files.

These two utilities can also be invoked from another application. Locate the program
path from its entry in the registry ( EG: HKCU\Software\VB and VBA Program Settings\Comp) and 
launch it with the following three parameters:
P1 - /t , /s or /w
P2 - full path of the source file, enclosed in double quotes.
P3 - full path of the target file, enclosed in double quotes.

Support
-------

If you have problems running this utility, or error messages occur, please take 
CAREFULL note of the error message, the files being processed etc and contact me 
via the info in the Help - About window.

WARNING
-------

There would seem to be an infinite number of permutations for W,S and T files
that can be found in the various routes. And manual editting of those files 
can seriously compound those considerations. For that reason, there is always a 
chance to discover a bug that can make the output file unusable (even crash MSTS).
SO, please make sure that you can recover the original files by taking appropriate
backup precautions.

Fixes
-----
Comp.exe 1.1.5
--------------
 - Added memory overflow tests before using CopyMemory Api
DeComp.exe 1.1.5
--------------
 - Removed debugging code for two bytes of token header
Both 1.1.6
----------
 - Stopped MSVCRT.DLL from being installed
Comp.exe 1.1.7
--------------
 - Mishandled quoted filename causes abend
Both 1.1.8
----------
 - Added support for quietmode if params supplied
 - Kill output file before overwritting
Both 1.1.9
----------
 - Handled float numbers in NA English format as required
   by MSTS

Martyn T. Griffin

